import Book.FormatBook;
import Student.Student;

public class AddModifyDelete {

    public static void addNewBook(String title, String IBW, String subject, String day,String month,String year, String author){
        FormatBook book = new FormatBook();
        book.setAuthor(author);
        book.setIBW(IBW);
        book.setPublish_date(day,month,year);
        book.setSubject(subject);
        book.setTitle(title);
        book.changeStatus(true);
        book.saveBook();

    }

    public static void ModifyBook(FormatBook book,String title, String IBW, String subject, String day,String month,String year, String author){

        book.setAuthor(author);
        book.setIBW(IBW);
        book.setPublish_date(day,month,year);
        book.setSubject(subject);
        book.setTitle(title);
        book.saveBook();

    }

    public static void deleteBook(FormatBook book)
    {
        //удаление из дб
    }


    public static void addNewStudent(String password,String login,String name, String surname, String ID) //Дописать сохранение в файл
    {
        Student student=new Student();
        student.setName(name);
        student.setSurname(surname);
        student.setID(ID);
        student.setPassword(password);
        student.setLogin(login);
    }

    public static void modifyStudent(Student student,String name, String surname, String ID) //Дописать сохранение
    {
        student.setName(name);
        student.setSurname(surname);
        student.setID(ID);
    }

    public static void deleteStudent(Student student)
    {
        //Вызвать обьект и удалить его из файла
    }


}
