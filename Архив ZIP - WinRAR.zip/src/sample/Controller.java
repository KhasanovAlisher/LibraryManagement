package sample;
import Administrator.Administrator;
import Student.Student;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    @FXML
    TextField LoginTextField;
    @FXML
    PasswordField passwordTextField;
    @FXML
    Button OkButton;
    @FXML
    RadioButton administratorRadioButton;
    @FXML
    RadioButton librarianRadioButton;
    @FXML
    RadioButton studentRadioButton;
    @FXML
    Label label;



    @FXML
    public void okButtonClick() throws Exception{
        Stage stage=new Stage();
        Parent root;

        if(administratorRadioButton.isSelected()){
            Administrator administrator = new Administrator();
            administrator.Login(LoginTextField.getText(),passwordTextField.getText());
            if(administrator.isLoggedIn()) {
                stage = (Stage) OkButton.getScene().getWindow();
                root = FXMLLoader.load(getClass().getResource("../Menu/administratorMenu.fxml"));
            }
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("An error has been encountered");
                alert.setContentText("Wrong login or password");

                alert.showAndWait();
                stage = (Stage) OkButton.getScene().getWindow();
                root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            }
        }
        else if(librarianRadioButton.isSelected()) {
            Administrator administrator = new Administrator();
            administrator.Login(LoginTextField.getText(), passwordTextField.getText());
            if (administrator.isLoggedIn()) {
                stage = (Stage) OkButton.getScene().getWindow();
                root = FXMLLoader.load(getClass().getResource("../Menu/administratorMenu.fxml"));
            }
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("An error has been encountered");
                alert.setContentText("Wrong login or password");

                alert.showAndWait();
                stage = (Stage) OkButton.getScene().getWindow();
                root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            }
        }
        else if(studentRadioButton.isSelected()) {
            Student student = new Student();
            student.Login(LoginTextField.getText(), passwordTextField.getText());
            if (student.isLoggedIn()) {
                stage = (Stage) OkButton.getScene().getWindow();
                root = FXMLLoader.load(getClass().getResource("../Book/addNewBook.fxml"));
            }
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("An error has been encountered");
                alert.setContentText("Wrong login or password");

                alert.showAndWait();
                stage = (Stage) OkButton.getScene().getWindow();
                root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            }
        }
        else{
            stage = (Stage) OkButton.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}






