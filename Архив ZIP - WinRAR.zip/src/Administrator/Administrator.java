
package Administrator;
import Base.Base;
import Book.*;
import Student.Student;

public class Administrator extends Base {


public Administrator(){
    setLogin("login");
    setPassword("password");
}
    public void viewBook(){


    }






}
