package Base;

import javafx.scene.control.RadioButton;
import javafx.scene.control.*;
import java.awt.*;

abstract public class Base {

    private String password="qwerty";
    private String login="hello";
    private boolean loggedIn;


    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void Login(String login,String password){
        if(this.password.equals(password) && this.login.equals(login))
            loggedIn =  true;
        else
            loggedIn = false;
    }

    public void Logout(){
        loggedIn = false;
    }


}
