package Book;

import Book.Book;

public class FormatBook  implements Book {

    private String title;
    private String IBW;
    private String subject;
    private String author;
    private String publish_date;
    private boolean free;

    public String getIBW() {

        return IBW;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getSubject() {
        return subject;
    }

    public boolean isFree() {
        return free;
    }

    public String getPublish_date() {
        return publish_date;
    }

    /////////////////////////////////////////////////


    public void saveBook(){

    }


    /////////////////////////////////////////////////

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setIBW(String IBW) {
        this.IBW = IBW;
    }


    public void setPublish_date(String day,String month, String year) {
        this.publish_date = day+"/"+month+"/"+year+".";
    }

    public void changeStatus(boolean free) {
        this.free = free;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return String.format("");
    }
}


