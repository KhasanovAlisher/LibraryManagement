package Book;

public interface Book {

    String getIBW();
    String getTitle();
    String getAuthor();
    String getSubject();
    boolean isFree();
    String getPublish_date();
}



