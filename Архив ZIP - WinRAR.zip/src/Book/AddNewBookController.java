package Book;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class AddNewBookController  {

    @FXML
    TextField titleTextField;
    @FXML
    TextField authorTextField;
    @FXML
    TextField subjectTextField;
    @FXML
    TextField publishDayTextField;
    @FXML
    TextField publishMonthTextField;
    @FXML
    TextField publishYearTextField;
    @FXML
    TextField numberTextField;
    @FXML
    Button okButton;
    @FXML
    VBox ISBNScrollBar;
    public boolean isDateCorrect(){
         if(Integer.parseInt(publishDayTextField.getText())>0 && Integer.parseInt(publishDayTextField.getText())<31 && Integer.parseInt(publishMonthTextField.getText())>0 && Integer.parseInt(publishMonthTextField.getText())<12)
             return true;
         else
             return false;
    }

    public void addNewBook(int number){
            TextField textField[]=new TextField[number];
            for(int i=0;i<number;i++){
                ISBNScrollBar.getChildren().add(textField[i]);
            }
        }


    public void numberISBN() {
        TextField textField[]=new TextField[Integer.parseInt(numberTextField.getText())];
        ISBNScrollBar.getChildren().clear();
        for(int i=0;i<Integer.parseInt(numberTextField.getText());i++){
            textField[i]=new TextField();
            ISBNScrollBar.getChildren().add(textField[i]);
        }
    }
}



