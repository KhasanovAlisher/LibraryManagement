package Student;
import Base.Base;
import Book.*;
public class Student extends  Base {
    String name;
    String surname;
    String ID;
    Book books[];
    int numberOfBook;


    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
//
//    public Book getBooks() {
//        return books;
//    }

    public void setBooks(FormatBook books) {
        this.books[numberOfBook]=books;
        setNumberOfBook();
    }

    public int getNumberOfBook() {
        return numberOfBook;
    }

    public void setNumberOfBook() {
        this.numberOfBook++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
