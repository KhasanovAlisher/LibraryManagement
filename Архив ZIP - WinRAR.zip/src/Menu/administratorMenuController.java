package Menu;

import Book.Book;

import Librarian.Librarian;
import Student.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;


public class administratorMenuController {

    ObservableList<Book> books = FXCollections.observableArrayList();
    @FXML
    Button studentButton;
    @FXML
    Button librarianButton;
    @FXML
    Button booksButton;
    @FXML
    Label label;
    @FXML
    HBox hBox;
    @FXML
    Button addButton;
    public void booksButtonClicked(){
        booksButton.
        TableView<Book> tableOfBook;
        TableColumn<Book, String> title = new TableColumn<>("Title");
        title.setMinWidth(200);
        title.setCellValueFactory(new PropertyValueFactory<>("Title"));
        TableColumn<Book, String> author = new TableColumn<>("Author");
        author.setMinWidth(100);
        author.setCellValueFactory(new PropertyValueFactory<>("Author"));
        TableColumn<Book, String> subject = new TableColumn<>("Subject");
        subject.setMinWidth(100);
        subject.setCellValueFactory(new PropertyValueFactory<>("Subject"));

        tableOfBook = new TableView<>();
        tableOfBook.getColumns().add(title);
        tableOfBook.getColumns().add(author);
        tableOfBook.getColumns().add(subject);
        hBox.getChildren().clear();
        hBox.getChildren().add(tableOfBook);
    }


    public void librarianButtonClicked(){
        TableView<Librarian> tableOfLibrarians;
        TableColumn<Librarian, String> fullName = new TableColumn<>("Full name");
        fullName.setMinWidth(200);
        fullName.setCellValueFactory(new PropertyValueFactory<>("Full name"));
        TableColumn<Librarian, String> author = new TableColumn<>("Author");
        author.setMinWidth(100);
        author.setCellValueFactory(new PropertyValueFactory<>("Author"));
        tableOfLibrarians = new TableView<>();
        tableOfLibrarians.getColumns().add(fullName);
        hBox.getChildren().clear();
        hBox.getChildren().add(tableOfLibrarians);


    }

    public void studentButtonClicked(){
        TableView<Student> tableOfStudents;
        TableColumn<Student, String> fullName = new TableColumn<>("Full name");
        fullName.setMinWidth(200);
        fullName.setCellValueFactory(new PropertyValueFactory<>("Full name"));
        TableColumn<Student, String> id = new TableColumn<>("ID");
        id.setMinWidth(100);
        tableOfStudents = new TableView<>();
        tableOfStudents.getColumns().add(fullName);
        tableOfStudents.getColumns().add(id);
        hBox.getChildren().clear();
        hBox.getChildren().add(tableOfStudents);

    }


}
