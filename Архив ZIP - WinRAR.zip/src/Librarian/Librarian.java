package Librarian;

import Base.Base;
import Book.FormatBook;
import Student.Student;
import Student.*;
import Book.FormatBook;

import java.awt.print.Book;

public class Librarian extends Base {

    String name;
    String surname;
    String ID;


    public Librarian() {
        setLogin("login");
        setPassword("password");

    }

    public void addNewBook(String title, String IBW, String subject, String day,String month,String year, String author){
        FormatBook book = new FormatBook();
        book.setAuthor(author);
        book.setIBW(IBW);
        book.setPublish_date(day,month,year);
        book.setSubject(subject);
        book.setTitle(title);
        book.changeStatus(true);
        book.saveBook();

    }


    public void ModifyBook(FormatBook book,String title, String IBW, String subject, String day,String month,String year, String author){

        book.setAuthor(author);
        book.setIBW(IBW);
        book.setPublish_date(day,month,year);
        book.setSubject(subject);
        book.setTitle(title);
        book.saveBook();

    }
    public void deleteBook(FormatBook book)
    {
        //удаление из дб
    }




    public void addNewStudent(String password,String login,String name, String surname, String ID) //Дописать сохранение в файл
    {
        Student student=new Student();
        student.setName(name);
        student.setSurname(surname);
        student.setID(ID);
        student.setPassword(password);
        student.setLogin(login);
    }

    public void modifyStudent(Student student,String name, String surname, String ID) //Дописать сохранение
    {
        student.setName(name);
        student.setSurname(surname);
        student.setID(ID);
    }

    public void deleteStudent(Student student)
    {
        //Вызвать обьект и удалить его из файла
    }




}
